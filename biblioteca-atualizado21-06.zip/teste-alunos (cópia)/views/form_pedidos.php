

    <div class="conteiner-fluid">
      <div class="container cartao-formulario espaco-cima">

        <div class=" titulo text-center">
        <h3>Cadastrar Pedidos</h3>
      </div>

        <div class="row">
         <div class="col-md-12">
            <form method="post" action="index.php?rota=adiciona_pedidos">
                <div class="form-row">
                  <div class="col-md-2"></div>
                  <div class="col-md-3">
                      <label>Turma</label>
                      <select class="form-control is-valid" name="turma" required />
                        <option selected="#"><?php if(isset($turma_s) == false){echo "Selecione";}else{echo $turma_s;} ?></option>
                        <?php foreach ($turmas as $turma) {
                          echo "<option onclick=location.href='index.php?rota=lista_pedidos&turma_s=$turma' value='$turma'>$turma</option>";
                         }
                        ?>
                      </select>
                  </div>
                  <div class="col-md-2"></div>
                  <div class="col-md-3">
                      <label for="">Data Entrega</label>
                      <input type="date" name="data_entrega" class="form-control is-valid" >
                  </div>
               </div>
               <div class="form-row">
                   <div class="col-md-2"></div>
                   <div class="col-md-3">
                    <label>Aluno</label>
                    <input list="alunos" name="codigo_aluno"  class="form-control is-valid"  required>
                     <datalist id="alunos">
                      <?php foreach($turmas_alunos[$turma_s] as $aluno):?>
                      <option value="<?php echo $aluno->getId(); ?>-<?php echo $aluno->getNome(); ?>">

                      <?php endforeach;   ?>
                     </datalist>
                   </div>
                   <div class="col-md-2"></div>
                   <div class="col-md-3">
                    <label>Livro</label>
                    <input list="livros" name="codigo_livro"  class="form-control is-valid"  required>
                     <datalist id="livros">
                      <?php foreach($livros as $livro):?>
                      <option value="<?php echo $livro->getCodigo(); ?>-<?php echo $livro->getTitulo();?>">
                      <?php endforeach;   ?>
                     </datalist>
                   </div>
               </div>
               <div class="row">
                   <div class="col-md-5"></div>
                   <div class="col-md-2">
                      <button class="btn botao-formulario espaco-cima" type="submit">Enviar</button>
                   </div>
              </div>
          </form>
       </div>
     </div>
   </div>
 </div>
