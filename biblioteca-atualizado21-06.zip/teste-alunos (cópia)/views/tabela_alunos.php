<div class="container-fluid">
   <div class="row">
    <div class="col-md-12 espaco-cima verde center">
     <h3><b>1° Ano</b></h3>
    </div>
   </div>

   <?php for($i=1 ; $i<=3 ; $i++):
     if($i < 2){  ?>
   <div class="row">
   <?php foreach($turmas as $turma): ?>
    <?php if($turma == "2A"){
      echo "  <div class='col-md-12 espaco-cima verde center' >
          <h3><b>2° Ano</b></h3>
        </div> ";
    }
    ?>
      <?php if($turma == "3A"){
        echo "  <div class='col-md-12 espaco-cima verde center'>
            <h3><b>3° Ano</b></h3>
          </div> ";
      }
       ?>
    <div class="col-md-3 espaco-cima">

      <h3><?php echo $turma;?></h3>
   <div class="table-responsive tabela_aluno ">
     <table class="table table-hover">
      <thead class="sticky-top cabecario-tabela text-center">
       <tr>
        <th>#</th>
        <th>Nome</th>
        <th>Remover</th>
       </tr>
      </thead>
      <tbody class="text-center">
        <?php $i=0; ?>
        <?php foreach($turmas_alunos[$turma] as $aluno):?>
       <?php
         $i++;
         ?>
          <tr >

           <td onclick=location.href="index.php?rota=editar_aluno&id=<?php echo $aluno->getId();?>" scope="row"><?php echo $i; ?></td>
           <td onclick=location.href="index.php?rota=editar_aluno&id=<?php echo $aluno->getId();?>" ><?php echo $aluno->getNome(); ?></td>
           <td ><a href="index.php?rota=remover_aluno&id=<?php echo $aluno->getId();?>"><i class="material-icons">delete_forever</i></a></td>
         </tr>
         <?php endforeach; ?>
      </tbody>
     </table>
   </div>
    </div>
  <?php endforeach; ?>
     </div>
  <?php } ?>
<?php endfor; ?>

</div>
