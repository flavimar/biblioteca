<nav aria-label="Page navigation">
  <ul class="pagination justify-content-center">
    <li class="page-item">
      <a class="page-link" href="index.php?rota=lista_pedidos&pagina_a=<?php echo 1; ?>" aria-label="Previous">
        <<
      </a>
    </li>
   <?php for($i=0;$i<$num_paginas_a;$i++): ?>
     <?php $estilo= "";?>
     <?php if($pagina_a == $i+1){
           $estilo ="active";
     }
     ?>
    <li class="page-item <?php echo $estilo;?>" ><a class="page-link" href="index.php?rota=lista_pedidos&pagina_a=<?php echo $i+1; ?>"><?php echo $i+1;?></a></li>

  <?php endfor; ?>
    <li class="page-item">
      <a class="page-link" href="index.php?rota=lista_pedidos&pagina_a=<?php echo $num_paginas_a; ?>" aria-label="Next">
        >>
      </a>
    </li>
  </ul>
</nav>
