
<div class="container-fluid espaco-cima">
<div class="table-responsive">
  <table class="table table-hover table-bordered ">
      <thead class="text-center" style="background: #047737; color:white;">
    <tr>
      <th >#</th>
      <th >Codigo</th>
			<th>Numero de Registro</th>
      <th >Titulo</th>
      <th >Autor</th>
      <th >Editora</th>
        <th colspan="2"><center>Remover</center></th>
    </tr>
  </thead>
  <tbody class="text-center">
<?php $i=1; ?>
    <?php
    foreach ($livros as $livro):
    ?>
    <tr onclick="location.href='index.php?rota=editar_livro&id=<?php echo $livro->getId(); ?>'">
      <th scope="row"><?php echo $i; ?></th>
      <td><?php echo $livro->getCodigo(); ?></td>
			<td><?php echo $livro->getNumero_registro(); ?></td>
      <td><?php echo $livro->getTitulo(); ?></td>
			<td><?php echo $livro->getAutor(); ?></td>
		<td><?php echo $livro->getEditora(); ?></td>
     <td><a href="index.php?rota=remover_livro&id=<?php echo $livro->getId(); ?>">
<i class="material-icons">delete_forever</i></a></td>
<?php
          $i++;
          ?>
     	<?php endforeach; ?>

    </tr>
  </tbody>
  </table>
</div>
</div>


<!-- Modal -->
<div class="modal fade" id="procurar_livros" tabindex="-1" role="dialog" aria-labelledby="div_procurar_livro" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
 <h5 class="modal-title" id="div_procurar_livro">Titulo Do Modal</h5>
 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
   <span aria-hidden="true">×</span>
 </button>
</div>
<div class="modal-body">
 <form>
 <label for="busca_livro">Digite o livro</label>
  <input list="livros" name="busca_livro" class="form-control is-valid" type="text" >
  <datalist id="livros">
   <?php foreach($livros as $livro):?>
     <?php echo $livro->getTitulo(); ?>

   <?php endforeach;   ?>
  </datalist>
 </form>
</div>
<div class="modal-footer">
 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
 <button type="button" class="btn btn-success">Save changes</button>
</div>
</div>
</div>
</div>

</body>
</html>
