<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <?php $titulo="Biblioteca"; ?>
    <title><?php echo $titulo; ?></title>
    <!-- Bootstrap -->
    <link rel="shortcut icon" href="img/1.ico" />
    <link href="views/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="views/css/estilo.css">
        <link rel="stylesheet" type="text/css" href="views/css/footer.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"><!--Icons Do Site-->
 <style>
  	@import url('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
 </style>
  </head>
  <body>
