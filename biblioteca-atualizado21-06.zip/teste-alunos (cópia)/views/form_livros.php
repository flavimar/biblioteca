
<!DOCTYPE html>
<html>
<head>
	<title>Biblioteca||Cadastrar Livros</title>
	<link rel="shortcut icon" href="img/1.ico" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <meta charset="utf-8"/>
		<style>

	</style>
</head>
<body>
  <div class="espaco-cima container cartao-formulario">
   <div class="col-md-12">
    <form style="margin-top: 22px;" method="post" action="index.php?rota=adiciona_livro">
      <div class="form-row">
       <div class="col-md-2"></div>
       <div class="col-md-3"><!--Inicio Do Formulario De Cadastrar-->
        <label for="validationServer01">Código</label>
        <input type="text" name="codigo" class="form-control is-valid" placeholder=""  required>
        <div class="valid-feedback">
        </div>
       </div>
       <div class="col-md-2"></div>
	   <div class="col-md-3">
		<label for="validationServer01">Numero De Registro</label>
		<input type="text" name="numero_registro" class="form-control is-valid"  placeholder=""  required>
		<div class="valid-feedback">
		</div>
	   </div>
      </div>
      <div class="form-row">
       <div class="col-md-2"></div>
       <div class="col-md-3">
         <label for="validationServer02">Titulo</label>
         <input type="text" name="titulo" class="form-control is-valid" placeholder=""  required>
         <div class="valid-feedback">
          <div class="col-md-2"></div>
         </div>
       </div>
       <div class="col-md-2"></div>
       <div class="col-2">
         <label for="validationServer03">Data de Publicação</label>
         <input type="date" name="data_publicacao" class="form-control is-valid" required>
         <div class="valid-feedback">
         </div>
       </div>
       <div class="col-1">
         <label>Ano_Entrega</label>
         <input type="year" name="ano_publicacao" class="form-control is-valid"  required>
         <div class="valid-feedback">
         </div>
       </div>
      </div>
      <div class="form-row">
        <div class="col-2"></div>
	    <div class="col-3">
	       <label>Exemplar_Livros</label>
	       <input type="name" name="exemplar_livros" class="form-control is-valid" required>
	       <div class="valid-feedback">
	       </div>
	    </div>
        <div class="col-md-2"></div>
        <div class="col-md-3">
          <label>Estado</label>
	  <select  type="text" name="local" class="form-control is-valid" required  title="Choose one of the following...">
		<option value="estado">Selecione o Estado</option>
		<option value="ac">Acre</option>
		<option value="al">Alagoas</option>
		<option value="am">Amazonas</option>
		<option value="ap">Amapá</option>
		<option value="ba">Bahia</option>
		<option value="ce">Ceará</option>
		<option value="df">Distrito Federal</option>
		<option value="es">Espírito Santo</option>
		<option value="go">Goiás</option>
		<option value="ma">Maranhão</option>
		<option value="mt">Mato Grosso</option>
		<option value="ms">Mato Grosso do Sul</option>
		<option value="mg">Minas Gerais</option>
		<option value="pa">Pará</option>
		<option value="pb">Paraíba</option>
		<option value="pr">Paraná</option>
		<option value="pe">Pernambuco</option>
		<option value="pi">Piauí</option>
		<option value="rj">Rio de Janeiro</option>
		<option value="rn">Rio Grande do Norte</option>
		<option value="ro">Rondônia</option>
		<option value="rs">Rio Grande do Sul</option>
		<option value="rr">Roraima</option>
		<option value="sc">Santa Catarina</option>
		<option value="se">Sergipe</option>
		<option value="sp">São Paulo</option>
		<option value="to">Tocantins</option>

</select>

          <div class="valid-feedback">
          </div>
        </div>
      </div>
      <div class="form-row">
        <div class="col-md-2"></div>
	    <div class="col-md-3">
	      <label>Autor</label>
	      <input type="text" name="autor" class="form-control is-valid" required>
	      <div class="valid-feedback">
           <div class="col-md-2"></div>
	      </div>
	    </div>
          <div class="col-md-2"></div>
        <div class="col-md-3">
          <label>Editora</label>
          <input type="text" name="editora" class="form-control is-valid" required>
          <div class="valid-feedback">
          </div>
    </div>
      <div class="col-md-2"></div>
        </div>
				<div class="row">
 					 <div class="col-md-5"></div>
 					 <div class="col-md-2">
 							<button class="btn botao-formulario espaco-cima" type="submit">Enviar</button>
 					 </div>
 			</div>
			</form><!--Fim Do Formulario De Cadastrar-->
		</div>
	</div>
