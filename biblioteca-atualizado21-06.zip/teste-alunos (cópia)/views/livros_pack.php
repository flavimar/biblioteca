
<!DOCTYPE html>
<html>
<head>
	<title>Biblioteca||Cadastrar Livros</title>
	<link rel="shortcut icon" href="img/1.ico" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <meta charset="utf-8"/>
		<style>
		hr{
		    border:1.1px solid #696969;
		    box-shadow: 0px 5px 30px #000;
		}
		.table td, .table th {
		  padding: 0.3rem;
		  text-align: center;
		  vertical-align: middle;
		  border-top: 1px solid #047737;
		}
		#btnenviar {
		  margin-top: 22px;
		  background-color: #047737;
		  border-color: #047737;
		  cursor: pointer;
		  color: #fff;
		  width: 20%;
		}
		.fa-pencil{
		  color: #047737;
		}
		  .fa-trash{
		    color: #047737;
		  }
		  #tamanhoicons {
		    font-size: 32px;
		  }
	</style>
</head>
<body>
	<?php
        include 'navbar.php';
      ?>
  <div class="conteiner">

   <div class="col-md-12">
    <form style="margin-top: 22px;" method="post" action="index.php?rota=adiciona_livro">
      <div class="form-row">
       <div class="col-md-2"></div>
       <div class="col-md-3"><!--Inicio Do Formulario De Cadastrar-->
        <label for="validationServer01">Código</label>
        <input  type="text" readonly name="codigo" value="<?php echo $dados[1]; ?>" class="form-control is-valid" id="validationServer01" placeholder="EX:.9337693"  required>
        <div class="valid-feedback">
        </div>
       </div>
       <div class="col-md-2"></div>
	   <div class="col-md-3">
		<label for="validationServer01">Numero De Registro</label>
		<input type="text" value="<?php echo $dados[9]; ?>" name="numero_registro" class="form-control is-valid" id="validationServer01" placeholder="EX:.9788532530271"  required>
		<div class="valid-feedback">
		</div>
	   </div>
      </div>
      <div class="form-row">
       <div class="col-md-2"></div>
       <div class="col-md-3">
         <label for="validationServer02">Titulo</label>
         <input type="text" name="titulo" readonly  value="<?php echo $dados[2]; ?>"  class="form-control is-valid" id="validationServer02" placeholder="EX:.Harry Potter e A Pedra Filosofal"  required>
         <div class="valid-feedback">
          <div class="col-md-2"></div>
         </div>
       </div>
       <div class="col-md-2"></div>
       <div class="col-2">
         <label for="validationServer03">Data de Publicação</label>
         <input type="text" readonly value="<?php echo $dados[3]; ?>" name="data_publicacao"  class="form-control is-valid" id="validationServer03" required>
         <div class="valid-feedback">
         </div>
       </div>
       <div class="col-1">
         <label for="validationServer04">Ano Entrega</label>
         <input type="year" readonly  value="<?php echo $dados[4]; ?>" name="ano_publicacao"  class="form-control is-valid" id="validationServer04" placeholder="EX:2018"  required>
         <div class="valid-feedback">
         </div>
       </div>
      </div>
      <div class="form-row">
        <div class="col-2"></div>
	    <div class="col-3">
	       <label name for="validationServer04">Exemplar_Livros</label>
	       <input type="name" value="<?php $dados[5]++; echo $dados[5]; ?>" name="exemplar_livros"  class="form-control is-valid" id="validationServer04" placeholder="EX:.01"  required>
	       <div class="valid-feedback">
	       </div>
	    </div>
        <div class="col-md-2"></div>
        <div class="col-md-3">
          <label for="validationServer01">Estado</label>
					<select  type="text" readonly name="local" class="form-control is-valid" id="validationServer01"  placeholder="EX:.São Paulo"  required  title="Choose one of the following...">
						<option value="estado"> <?php echo $dados[6]; ?></option>


</select>

          <div class="valid-feedback">
          </div>
        </div>
      </div>
      <div class="form-row">
        <div class="col-md-2"></div>
	    <div class="col-md-3">
	      <label for="validationServer02">Autor</label>
	      <input type="text" readonly name="autor"  value="<?php echo $dados[7]; ?>" class="form-control is-valid"  id="validationServer02" placeholder="EX:.Rowling, J. K."  required>
	      <div class="valid-feedback">
           <div class="col-md-2"></div>
	      </div>
	    </div>
          <div class="col-md-2"></div>
        <div class="col-md-3">
          <label for="validationServer01">Editora</label>
          <input type="text" readonly  value="<?php echo $dados[8]; ?>" name="editora" class="form-control is-valid"  id="validationServer01" placeholder="EX:.Rocco"  required>
          <div class="valid-feedback">
          </div>
    </div>
      <div class="col-md-2"></div>
        </div>
        <div class="form-row">
	                 <div class="row-md-offset-8"></div>
                   <div class="col-md-12" style="padding: 5px;"><center><button id="btnenviar" class="btn btn-success button" type="submit" id="btnenviar">Enviar</button></center>
            </div>

        </div>
			</form><!--Fim Do Formulario De Cadastrar-->


  <hr>
