<div class="container-fluid espaco-cima">
  <div class="row">
      <div class="col-md-6">
      <div class="titulo text-center"><h3>Emprestimos<h3></div>

          <table class="table table-striped table-bordered ">
              <thead class="cabecario-tabela">
                  <tr>
                      <th><div class="text-center">#</div></th>
                      <th><div class="text-center">Aluno</div></th>
                      <th><div class="text-center">Turma</div></th>
                      <th><div class="text-center">Titulo</div></th>
                      <th><div class="text-center">Cod.Livro</div></th>
                      <th><div class="text-center">Prazo</div></th>
                      <th><div class="text-center">Ação</div></th>
                  </tr>
              </thead>
              <tbody>
                <?php
                       $c=0;
                      if($pagina > 1){
                        $c=(($pagina-1)*$pedidos_por_pagina);
                      }
                  ?>
                <?php foreach($pedidos as $pedido):?>

                  <?php
                      $c++; ?>
                <?php

                $data2 = new DateTime($pedido->getDataEntrega());
                $mes_entrega = (int)$data2->format('m');
                $dia_entrega = (int)$data2->format('d');
                $data_atual = new DateTime("now");
                $mes_atual = (int)$data_atual->format('m');
                $dia_atual = (int)$data_atual->format('d');
                $prazo_dia = $dia_entrega - $dia_atual ;
                $prazo_mes = $mes_entrega - $mes_atual;
              ?>
                 <tr class="text-center">
                      <td><?php echo $c; ?></td>
                      <td class=" " onmouseout="volta_cor(this) " onmouseover="muda_cor(this)" onclick=location.href="index.php?rota=info_aluno&id=<?php echo $pedido->getAluno()->getId();?>"><?php echo $pedido->getAluno()->getNome(); ?></td>
                      <td ><?php echo $pedido->getAluno()->getTurma(); ?> </td>
                      <td class=" " onmouseout="volta_cor(this) " onmouseover="muda_cor(this)" onclick=location.href="index.php?rota=info_livro&id=<?php echo $pedido->getLivro()->getId();?>"><?php echo $pedido->getLivro()->getTitulo(); ?></td>
                      <td><?php echo $pedido->getCodigoLivro(); ?></td>
                      <td><?php echo $prazo_mes.' meses'.' e '.$prazo_dia.' dias restantes'; ?></td>
                       <td><a href="index.php?rota=remover_pedido&id=<?php echo $pedido->getId();?>">OK</a></td>
                  </tr>




<?php endforeach;  ?>

              </tbody>

        </table>
        <?php require "views/paginacao_tab_pedidos.php"; ?>
      </div>


    <div class="col-md-6">
      <div class="titulo text-center"><h3>Atrasos</h3></div>

        <table class="table table-striped table-bordered ">
          <thead class="bg-danger text-white">
           <tr>
            <th>#</th>
            <th><div class="text-center">Aluno</div></th>
            <th><div class="text-center">Turma</div></th>
            <th><div class="text-center">Titulo</div></th>
            <th><div class="text-center">Cod.Livro</div></th>
            <th><div class="text-center">Atraso</div></th>
            <th><div class="text-center">Ação</div></th>
           </tr>
          </thead>
         <tbody>
           <?php
            $n=0;
            if($pagina > 1){
              $n=(($pagina-1)*$pedidos_por_pagina);
            }
        foreach ($pedidos_a as $pedido_a):
          $n++;
            ?>


             <?php

             $data2 = new DateTime($pedido_a->getDataEntrega());
             $mes_entrega = (int)$data2->format('m');
             $dia_entrega = (int)$data2->format('d');
             $data_atual = new DateTime("now");
             $mes_atual = (int)$data_atual->format('m');
             $dia_atual = (int)$data_atual->format('d');
             $prazo_dia = $dia_entrega - $dia_atual ;
             $prazo_mes = $mes_entrega - $mes_atual;
           ?>

           <tr class="text-center">
                <td><?php echo $n; ?></td>
                <td class=" " onmouseout="volta_cor(this) " onmouseover="muda_vermelho(this)" onclick=location.href="index.php?rota=info_aluno&id=<?php echo $pedido_a->getAluno()->getId();?>"><?php echo $pedido_a->getAluno()->getNome(); ?></td>
                <td ><?php echo $pedido_a->getAluno()->getTurma(); ?> </td>
                <td class=" " onmouseout="volta_cor(this) " onmouseover="muda_vermelho(this)" onclick=location.href="index.php?rota=info_livro&id=<?php echo $pedido_a->getLivro()->getId();?>"><?php echo $pedido_a->getLivro()->getTitulo(); ?></td>
                <td><?php echo $pedido_a->getCodigoLivro(); ?></td>
                <td><?php echo -$prazo_mes.' meses'.' e '.-$prazo_dia.' dias de atraso'; ?></td>
                 <td><a href="index.php?rota=remover_pedido_a&id=<?php echo $pedido_a->getId();?>">OK</a></td>
            </tr>

            <?php endforeach; ?>
              </tbody>
          </table>
         <?php require "views/paginacao_tab_pedidos_atrazados.php"; ?>


      </div>
    </div>
  </div>

  <!-- Tabela_Cadrastrados Fim -->
<script>
function muda_cor(x){
 x.className="verde";

}
function volta_cor(x){
x.className= " ";
}
function muda_vermelho(x){
  x.className = "bg-danger text-white";


}


</script>
