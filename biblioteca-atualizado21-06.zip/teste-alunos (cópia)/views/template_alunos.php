
<?php require "views/form_alunos.php"; ?>

<?php require "views/tabela_alunos.php"; ?>
