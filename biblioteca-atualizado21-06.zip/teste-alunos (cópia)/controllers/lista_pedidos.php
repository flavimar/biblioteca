<?php
 $pedidos_por_pagina = 4;
 function verifica_pedidos($repositorio_pedidos){
	$pedido_a = $repositorio_pedidos->muda_pedidos_para_atrazados();
	if($pedido_a != []){
	   echo count($pedido_a);




	    $codigo_aluno = $pedido_a->getCodigoAluno();
	   $codigo_livro = $pedido_a->getCodigoLivro();
	   $data_entrega = $pedido_a->getDataEntrega();

	     echo $codigo_aluno;
	   $pedido_a = new Pedido($codigo_aluno,$codigo_livro,$data_entrega);


	 $repositorio_pedidos->adiciona_pedidos_atrazados($pedido_a);



	}
}
if(array_key_exists("turma_s", $_GET)){
	$turma_s = (string) $_GET["turma_s"];

}
if(array_key_exists("pagina", $_GET)){
	$pagina =  intval($_GET["pagina"]);

}
else{
	$pagina = 1;
}
if(array_key_exists("pagina_a", $_GET)){
	$pagina_a =  intval($_GET["pagina_a"]);
}
else{
	$pagina_a = 1;
}


  verifica_pedidos($repositorio_pedidos);
	$pedidos = $repositorio_pedidos->busca_pedidos($pagina,$pedidos_por_pagina);
	$num_paginas = $repositorio_pedidos->total_paginas($pedidos_por_pagina);
	$pedidos_a = $repositorio_pedidos->busca_pedidos_atrazados($pagina_a,$pedidos_por_pagina);
  $num_paginas_a = $repositorio_pedidos->total_paginas_atrazadas($pedidos_por_pagina);
  $livros = $repositorio_livros->busca_livros();
	$turmas = ['1A','1B','1C','1D','2A','2B','2C','2D','3A','3B','3C','3D'];
	$turmas_alunos = [];
	foreach ($turmas as $turma) {
	  $alunos = $repositorio_alunos->busca_alunos_por_turma($turma);
	  $turmas_alunos[$turma] = $alunos;

	}


	require __DIR__."/../views/template_pedidos.php";
?>
