<?php
require __DIR__."/../views/busca.php"; ?>
<div  class="table-responsive">
  <table id="table" style="display:none;"  class="table table-hover">
      <thead class="text-center" style="background: #047737; color:white;">
    <tr>
      <th >#</th>
      <th >Codigo</th>
      <th>Numero_Registro</th>
      <th >Titulo</th>
        <th colspan="1"><center>Acões</center></th>
    </tr>
  </thead>
  <tbody>
<?php $a=1; $b=0;?>

    <tr>

<th scope="row"><?php echo $a; ?></th>
<?php


		$SendPesqUser = filter_input(INPUT_POST, 'SendPesqUser', FILTER_SANITIZE_STRING);
		if($SendPesqUser){
			$titulo = filter_input(INPUT_POST, '_titulo', FILTER_SANITIZE_STRING);
			$result_livros = "SELECT * FROM lista_livros WHERE titulo LIKE '%$titulo%'";
			$resultado_livros = mysqli_query($conn, $result_livros);
			while($row_livros = mysqli_fetch_assoc($resultado_livros)){
				echo "<td>" . $row_livros['id'];$b++ . "</td>";
				echo "<td> " . $row_livros['titulo'] . "</td>";
				echo "  <td>" . $row_livros['codigo'] . "</td>";
				echo "<td> <a href='index.php?rota=edicao&id=" . $row_livros['id'] . "'>Editar</a>";
				echo " <a href='index.php?rota=remover&id=" . $row_livros['id'] . "'>Apagar</a></td>";

			}
		}


		?><?php $a++; ?>
  </tr>
</tbody>
</table>
<script>

if (<?php echo $b ?> >= 1){
document.getElementById("table").style.display = "";
}
</script>
</div>



<?php

	$livros = $repositorio_livro->busca_livros();
  $numero_colunas = 3;
  $quant_livros = count($livros);
  $numero_linhas = $quant_livros/$numero_colunas;

  $num_colunas_exibir = $numero_colunas;

	require __DIR__."/../views/template_lista.php";
?>
