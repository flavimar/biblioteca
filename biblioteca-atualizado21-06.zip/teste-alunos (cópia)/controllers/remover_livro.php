<?php
  $repositorio_livros->remove($_GET["id"]);
  require __DIR__."/../controllers/lista_livros.php";
?>
