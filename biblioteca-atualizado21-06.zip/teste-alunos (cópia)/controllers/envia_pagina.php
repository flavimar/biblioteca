<?php
$pagina = 1;
$pagina = intval($_GET['pagina']);
 $repositorio_pedidos->busca_pedidos($pagina);

 require __DIR__."/../controllers/lista_pedidos.php";



?>
