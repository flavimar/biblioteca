<?php

      //$id = $_POST['id'];

		  $titulo = $_POST['titulo'];
	    $codigo = $_POST['codigo'];
	    $data_publicacao = $_POST['data_publicacao'];
	    $ano_publicacao = $_POST['ano_publicacao'];
			$exemplar_livros = $_POST['exemplar_livros'];
			$local = $_POST['local'];
			$autor = $_POST['autor'];
      $numero_registro = $_POST['numero_registro'];
			$editora = $_POST['editora'];

      $livro = new Livro($titulo,$codigo,$data_publicacao,$ano_publicacao,$exemplar_livros,$local,$autor,$numero_registro,$editora);
    $repositorio_livro->adiciona($livro);
$contador = 1;

  if ($exemplar_livros > 1 ) {

  	 header("Location: index.php?rota=adiciona_pack&numero_registro=$numero_registro&contador=$contador");
  }
  else {


   header("Location: index.php");

  }

echo $id;

?>
