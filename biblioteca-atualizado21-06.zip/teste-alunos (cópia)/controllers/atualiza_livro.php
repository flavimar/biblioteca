<?php


	$livro_atualizado = new Livro();
	   $livro_atualizado->setId($_POST["id"]);
        $livro_atualizado->setTitulo($_POST["titulo"]);
  $livro_atualizado->setNumero_registro($_POST["numero_registro"]);
    $livro_atualizado->setCodigo($_POST["codigo"]);
	$livro_atualizado->setData_publicacao($_POST["data_publicacao"]);
  $livro_atualizado->setAno_publicacao($_POST["ano_publicacao"]);
	$livro_atualizado->setExemplar_livros($_POST['exemplar_livros']);
	$livro_atualizado->setLocal($_POST['local']);
	$livro_atualizado->setAutor($_POST['autor']);
	$livro_atualizado->setEditora($_POST['editora']);

  $repositorio_livro->atualiza($livro_atualizado);

	 header('Location: index.php?rota=lista');


?>
