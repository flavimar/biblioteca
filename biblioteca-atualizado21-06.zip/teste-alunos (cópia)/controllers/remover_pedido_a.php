<?php
   $repositorio_pedidos->remove_pedido_atrazado($_GET["id"]);
   require __DIR__."/../controllers/lista_pedidos.php";
?>
