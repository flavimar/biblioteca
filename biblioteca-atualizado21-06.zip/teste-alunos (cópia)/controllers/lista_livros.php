<?php

	$livros = $repositorio_livros->busca_livros();


	require __DIR__."/../views/template_livros.php";
?>
