-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Tempo de geração: 20/06/2018 às 18:46
-- Versão do servidor: 10.1.28-MariaDB
-- Versão do PHP: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `alunos`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno`
--

CREATE TABLE `aluno` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) DEFAULT NULL,
  `turma` varchar(5) DEFAULT NULL,
  `cidade` varchar(100) DEFAULT NULL,
  `bairro` varchar(100) DEFAULT NULL,
  `complementos` varchar(255) DEFAULT NULL,
  `numero_casa` varchar(5) DEFAULT NULL,
  `telefone` varchar(12) DEFAULT NULL,
  `rua` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `aluno`
--

INSERT INTO `aluno` (`id`, `nome`, `turma`, `cidade`, `bairro`, `complementos`, `numero_casa`, `telefone`, `rua`) VALUES
(64, 'Murilo Farias ', '1D', 'Tamboril', 'monte castelo', '', 's/n', '88992984342', ''),
(65, 'AndrÃ© Vitor', '2A', 'Tamboril', 'Conj. JosÃ© Alves TimbÃ³', '', 's/n', '88994538965', ''),
(66, 'Thalisson Mesquista', '2B', 'Carvalho/CE', 'Interior', '', 's/n', '88993307272', ''),
(68, 'JoÃ£o Lucas', '3B', 'Tamboril', 'Conj. JosÃ© Alves TimbÃ³', '', '227', '88992506167', ''),
(69, 'Nailton Melo', '3B', 'Tamboril', 'monte azul', '', '16', '88994811479', NULL),
(70, 'Iasmyn Vieira', '3A', 'Oliveiras/CE', 's/nome', '', 's/n', 'n/tem', NULL),
(71, 'Everson Ribeiro', '3A', 'Tamboril', 'Monte Castelo', '', 's/n', '88994518103', ''),
(72, 'DayrlÃ¢ne Sousa', '3D', 'Catunda/CE', 'Flamengo/Ce', 'PrÃ³ximo a escola TomÃ© Alves Martins ', 's/n', '88994797608', NULL),
(73, 'flavimar', '3D', 'Catunda/CE', 'monte azul', '', 's/n', '88992095211', ''),
(74, 'flavio', '3D', 'Tamboril', 'monte azul', '', 's/n', '890492043408', 'vicente alves do vale'),
(77, 'alibe', '3D', 'tamboril', 'monte azul', '', 's/n', '99999999', 's/r'),
(78, 'vicente monstro', '2B', 'Tamboril', 'monte azul', '', 's/n', '99999999', 'eerwe');

-- --------------------------------------------------------

--
-- Estrutura para tabela `lista_livros`
--

CREATE TABLE `lista_livros` (
  `titulo` varchar(100) DEFAULT NULL,
  `data_publicacao` date DEFAULT NULL,
  `ano_publicacao` int(11) DEFAULT NULL,
  `exemplar_livros` varchar(100) DEFAULT NULL,
  `local` varchar(200) DEFAULT NULL,
  `autor` varchar(100) DEFAULT NULL,
  `editora` varchar(100) DEFAULT NULL,
  `numero_registro` varchar(20) DEFAULT NULL,
  `codigo` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `lista_livros`
--

INSERT INTO `lista_livros` (`titulo`, `data_publicacao`, `ano_publicacao`, `exemplar_livros`, `local`, `autor`, `editora`, `numero_registro`, `codigo`, `id`) VALUES
('weryrty', '2018-05-09', 4324, 'sdfs', 'dasd', 'asdasd', 'asdas', 'asdas', 321, 1),
('rtert', '2018-05-16', 453, 'rdwfss', 'dfsfsdf', 'dfdsfsdf', 'sdfsdf', 'sdfsdf', 123, 2);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `codigo_aluno` int(11) DEFAULT NULL,
  `data_retirada` date DEFAULT NULL,
  `data_entrega` date DEFAULT NULL,
  `codigo_livro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `pedidos`
--

INSERT INTO `pedidos` (`id`, `codigo_aluno`, `data_retirada`, `data_entrega`, `codigo_livro`) VALUES
(93, 68, '2018-06-05', '2018-06-21', 321),
(95, 73, '2018-06-05', '2018-06-26', 321),
(102, 77, '2018-06-12', '2018-06-21', 321);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos_a`
--

CREATE TABLE `pedidos_a` (
  `id` int(11) NOT NULL,
  `codigo_aluno` int(11) DEFAULT NULL,
  `codigo_livro` int(11) DEFAULT NULL,
  `data_entrega` date DEFAULT NULL,
  `data_retirada` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Fazendo dump de dados para tabela `pedidos_a`
--

INSERT INTO `pedidos_a` (`id`, `codigo_aluno`, `codigo_livro`, `data_entrega`, `data_retirada`) VALUES
(14, 73, 123, '2018-06-12', NULL),
(15, 72, 123, '2018-06-12', NULL),
(18, 65, 123, '2018-06-13', NULL),
(19, 69, 321, '2018-06-13', NULL),
(20, 68, 123, '2018-06-13', NULL),
(21, 72, 321, '2018-06-20', NULL),
(22, 74, 123, '2018-06-19', NULL),
(23, 74, 123, '2018-06-11', NULL);

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `lista_livros`
--
ALTER TABLE `lista_livros`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo` (`codigo`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `codigo_aluno` (`codigo_aluno`),
  ADD KEY `codigo_livro` (`codigo_livro`);

--
-- Índices de tabela `pedidos_a`
--
ALTER TABLE `pedidos_a`
  ADD PRIMARY KEY (`id`),
  ADD KEY `codigo_aluno` (`codigo_aluno`),
  ADD KEY `codigo_livro` (`codigo_livro`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `aluno`
--
ALTER TABLE `aluno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT de tabela `lista_livros`
--
ALTER TABLE `lista_livros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT de tabela `pedidos_a`
--
ALTER TABLE `pedidos_a`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `codigo_livro` FOREIGN KEY (`codigo_livro`) REFERENCES `lista_livros` (`codigo`),
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`codigo_aluno`) REFERENCES `aluno` (`id`);

--
-- Restrições para tabelas `pedidos_a`
--
ALTER TABLE `pedidos_a`
  ADD CONSTRAINT `pedidos_a_ibfk_1` FOREIGN KEY (`codigo_aluno`) REFERENCES `aluno` (`id`),
  ADD CONSTRAINT `pedidos_a_ibfk_2` FOREIGN KEY (`codigo_livro`) REFERENCES `lista_livros` (`codigo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
