<?php
     date_default_timezone_set('America/Sao_Paulo');


    require "views/cabecalho.php";
    require "conexao.php";
    require "models/aluno.php";
    require "models/repositorio_alunos.php";
    require "models/pedido.php";
    require "models/repositorio_pedido.php";
    require "models/livros.php";
    require "models/repositorio_livros.php";
    $repositorio_alunos = new RepositorioAluno($conexao);
    $repositorio_livros = new RepositorioLivro($conexao);
    $repositorio_pedidos = new RepositorioPedidos($conexao,$repositorio_alunos,$repositorio_livros);


     $rota = "lista_livros";


    if(array_key_exists("rota", $_GET)){
      $rota = (string) $_GET["rota"];
    }
  if($rota != 'info_aluno' && $rota != 'info_livro' && $rota != 'editar_aluno' && $rota != 'editar_livro'){
    include "views/navbar.html";
}

    if(is_file("controllers/{$rota}.php")){
      require "controllers/{$rota}.php";
    }
    else{
      echo "Rota não encontrada";
    }

 if($rota != 'info_aluno' && $rota != 'info_livro' && $rota != 'editar_aluno' && $rota != 'editar_livro'){
   include 'views/footer.html';
 }


   require "views/rodape.html";
?>
