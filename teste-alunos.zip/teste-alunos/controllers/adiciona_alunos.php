<?php

		  $nome = $_POST['nome'];
	    $turma = $_POST['turma'];
	    $telefone = $_POST['telefone'];
	    $cidade = $_POST['cidade'];
			$bairro = $_POST['bairro'];
			$numero_casa = $_POST['numero_casa'];
			$complementos = $_POST['complementos'];


		$aluno = new Aluno($nome,$turma,$telefone,$cidade,$bairro,$numero_casa,$complementos);

		$repositorio_alunos->adiciona($aluno);




	require __DIR__."/../controllers/lista.php";
?>
