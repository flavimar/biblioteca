
<!doctype html>
<html>
  <head>
    <title>Biblioteca||Alunos</title>
    <link rel="shortcut icon" href="img/1.ico" />
      <!--Icons Do Site-->
        <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
    /* fallback */
@font-face {
  font-family: 'Material Icons';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/materialicons/v36/flUhRq6tzZclQEJ-Vdg-IuiaDsNc.woff2) format('woff2');
}

.material-icons {
  font-family: 'Material Icons';
  font-weight: normal;
  font-style: normal;
  font-size: 24px;
  line-height: 1;
  letter-spacing: normal;
  text-transform: none;
  display: inline-block;
  white-space: nowrap;
  word-wrap: normal;
  direction: ltr;
  -moz-font-feature-settings: 'liga';
  -moz-osx-font-smoothing: grayscale;
}
     .tabela_aluno{
       height:250px;
       overflow:auto;
       background:#fff;
       box-shadow:2px 3px 10px;

     }
      thead{
        background-color:#047737 ;
          color: white;
      }
      #anos_sala{
        background-color: #047737;
        text-align: center;
        color: white;
      }


     .res{
       text-align: center;
     }
     .espaco-cima{
       margin-top:10px;
     }



       .btn-cor{
         background: white;
         }
       .btn-success {
         color: #fff;
         background-color: #047737;
         border-color: #047737;
         }

        .button{
         width: 20%;
        }
        #btnenviar{
         margin-top: 22px;
}

  hr{
  border:1.5px solid #696969;
  box-shadow:3px 5px 6px #000;
}

  </style>
  </head>
  <body>

      <div class="container">
        <div class="col-md-12">
         <form style="margin-top: 22px" method="post" action="index.php?rota=adiciona_alunos">
          <div class="form-row">
           <div class="col-md-2"></div>
           <div class="col-md-3">
            <label for="validationServer01">Nome</label>
            <input type="text" class="form-control is-valid" name="nome" placeholder="Lucas Gomes" required>
           </div>
           <div class="col-md-2"></div>
           <div class="col-md-3">
            <label for="validationServer02">Telefone</label>
            <input type="text" class="form-control is-valid" name="telefone" placeholder="(88) 99999-9999" required>
           </div>
          </div>
             <div class="form-row">
          <div class="col-md-2"></div>
          <div class="col-md-3">
           <label for="cidade">Cidade</label>
           <input type="text" class="form-control is-valid" name="cidade" placeholder="Tamboril"   required>
           <div class="valid-feedback">
           </div>
          </div>
                   <div class="col-md-2"></div>
           <div class="col-md-3">
            <label for="validationServer01">Bairro</label>
            <input type="text" class="form-control is-valid" name="bairro" placeholder="praca 11" required>
            <div class="valid-feedback">
            </div>
           </div>
             </div>
          <div class="form-row">
          <div class="col-md-2"></div>
          <div class="col-md-3">
           <label for="validationServer01">N° Casa</label>
           <input type="text" class="form-control is-valid" name="numero_casa" placeholder="22" required>
           <div class="valid-feedback">
           </div>
          </div>
           <div class="col-md-2"></div>
          <div class="col-md-3">
            <label class="my-1 mr-2" for="inlineFormCustomSelectPref">Turma</label>
             <select class="custom-select my-1 mr-sm-2" name="turma"
              <option selected="#">Selecione</option>
              <option value="1A">1° A</option>
              <option value="1B">1° B</option>
              <option value="1C">1° C</option>
              <option value="1D">1° D</option>
              <option value="2A">2° A</option>
              <option value="2B">2° B</option>
              <option value="2C">2° C</option>
              <option value="2D">2° D</option>
              <option value="3A">3° A</option>
              <option value="3B">3° B</option>
              <option value="3C">3° C</option>
              <option value="3D">3° D</option>
            </select>
          </div>
          </div>
         <div class="form-row">
          <div class="col-md-2"></div>
          <div class="col-md-3">
           <label for="validationServer01">Complementos</label>
           <input type="text" class="form-control is-valid" name="complementos" placeholder="">
          </div>

         </div>
	                 <div class="row-md-offset-8"></div>
                   <div class="col-md-12" style="padding: 5px;"><center><button class="btn btn-success button" type="submit" id="btnenviar">Enviar</button></center>
            </div>
             </form>
    </div>
      </div>
      <hr>
   <div class="container-fluid">
    <div class="row">
     <div class="col-md-12 espaco-cima" id="anos_sala">
      <h3><b>1° Ano</b></h3>
     </div>
    </div>
   </div>
   <div class="container margin">
    <div class="row">
     <div class="col-md-3 res">
      </div>
    </div>
   </div>
   <div class="container-fluid">
    <?php for($i=1 ; $i<=3 ; $i++):
      if($i < 2){  ?>
    <div class="row">
    <?php foreach($turmas as $turma): ?>
     <?php if($turma == "2A"){
       echo "  <div class='col-md-12' id='anos_sala'>
           <h3><b>2° Ano</b></h3>
         </div>
       "
      ;
     }
       ?>
       <?php if($turma == "3A"){
         echo "  <div class='col-md-12' id='anos_sala'>
             <h3><b>3° Ano</b></h3>
           </div>
         "
        ;
       }
         ?>
     <div class="col-md-3 espaco-cima">

       <h3><?php echo $turma;?></h3>
    <div class="">
      <table class="table tabela_aluno table-responsive">
       <thead>
        <tr>
         <th>#</th>
         <th>Nome</th>
         <th>Editar</th>
         <th>Remover</th>
        </tr>
       </thead>
       <tbody>
         <?php foreach($turmas_alunos[$turma] as $aluno): ?>
           <tr>
            <td scope="row"><?php echo $aluno->getId();?></td>
            <td><?php echo $aluno->getNome(); ?></td>

         <td><a href="index.php?rota=edicao&id=<?php echo $aluno->getId();?>"><i class="material-icons">mode_edit</i></a></td>
         <td><a href="index.php?rota=remover&id=<?php echo $aluno->getId();?>"><i class="material-icons">delete_forever</i></a></td>
        </tr>


          <?php endforeach; ?>
       </tbody>
      </table>
    </div>
     </div>
   <?php endforeach; ?>
      </div>
   <?php } ?>
 <?php endfor; ?>
    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->

  </body>
</html>
