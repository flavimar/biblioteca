<?php
   require __DIR__."/../views/livros.php";
?>

<?php

	$livros = $repositorio_livro->busca_livros();
  $numero_colunas = 3;
  $quant_livros = count($livros);
  $numero_linhas = $quant_livros/$numero_colunas;

  $num_colunas_exibir = $numero_colunas;

	require __DIR__."/../views/template_lista.php";
?>
