<?php
$pedido_a = $repositorio_pedidos->muda_pedidos_para_atrazados();
if($pedido_a == []){

 echo "<script>alert('VAZIO')</script>";
 require __DIR__."/../controllers/lista_pedidos.php";
}
else{
   echo count($pedido_a);




    $codigo_aluno = $pedido_a->getCodigoAluno();
   $codigo_livro = $pedido_a->getCodigoLivro();
   $data_entrega = $pedido_a->getDataEntrega();

     echo $codigo_aluno;
   $pedido_a = new Pedido($codigo_aluno,$codigo_livro,$data_entrega);


 $repositorio_pedidos->adiciona_pedidos_atrazados($pedido_a);


 require __DIR__."/../controllers/lista_pedidos.php";
}
  ?>
