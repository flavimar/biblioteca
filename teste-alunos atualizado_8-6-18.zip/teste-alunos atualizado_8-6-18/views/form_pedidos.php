<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">

    <title>Biblioteca|| Pedidos De Livros</title>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/estilo.css">
    <style>




    </style>
</head>

<body>




    <div class="conteiner-fluid">
      <div class="container cartao-formulario espaco-cima">
        <div class="row">
         <div class="col-md-12">
            <form method="post" action="index.php?rota=adiciona_pedidos">
                <div class="form-row">
                  <div class="col-md-2"></div>
                  <div class="col-md-3">
                   <div class="form-row">
                     <div class="col-md-6">
                      <label>Turma</label>
                      <select class="custom-select my-1 mr-sm-2" name="turma" required />
                        <option selected="#"><?php if(isset($turma_s) == false){echo "Selecione";}else{echo $turma_s;} ?></option>
                        <?php foreach ($turmas as $turma) {
                          echo "<option onclick=location.href='index.php?rota=lista_pedidos&turma_s=$turma' value='$turma'>$turma</option>";
                         }
                        ?>
                      </select>
                     </div>
                     <div class="col-md-6">
                      <label>Aluno</label>
                      <input list="browsers" name="codigo_aluno"  class="form-control is-valid"  required>
                       <datalist id="browsers">
                        <?php foreach($turmas_alunos[$turma_s] as $aluno):?>
                        <option value="<?php echo $aluno->getId(); ?>-<?php echo $aluno->getNome(); ?>">

                        <?php endforeach;   ?>
                       </datalist>
                     </div>
                   </div>
                  </div>
                  <div class="col-md-2"></div>
                  <div class="col-md-3">
                      <label for="validationServer04">Data Entrega</label>
                      <input type="date" name="data_entrega" class="form-control is-valid" >
                  </div>
               </div>
               <div class="form-row">
                    <div class="col-md-2"></div>
                    <div class="col-md-3">
                        <label for="validationServer03">Codigo do Livro</label>
                        <input type="number" name="codigo_livro" class="form-control is-valid">
                    </div>
               </div>
               <div class="row">
                   <div class="col-md-5"></div>
                   <div class="col-md-2">
                      <button class="btn botao-formulario espaco-cima" type="submit">Enviar</button>
                   </div>
              </div>
          </form>
       </div>
     </div>
   </div>
 </div>

  <div class="container-fluid espaco-cima">
    <div class="row">
        <div class="col-md-6">
          <div class="">
            <table class="table table-striped ">
                <thead class="cabecario-tabela">
                    <tr>
                        <th>Turma</th>
                        <th>Aluno</th>
                        <th>Titulo</th>
                        <th>Codigo Livro</th>
                        <th>Prazo</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>

                  <?php foreach($pedidos as $pedido):?>


                  <?php

                  $data2 = new DateTime($pedido->getDataEntrega());

                  $data_atual = new DateTime("now");

                  $prazo = $data_atual->diff($data2);


                  if($data2 < $data_atual){
                    $prazo ="-$prazo->d";


                  }
                  else{
                   $prazo = $prazo->d;
                 }
                   ?>
                  <?php if($prazo >= 0){ ?>
                   <tr>
                        <td ><?php echo $pedido->getAluno()->getTurma(); ?> </td>
                        <td class=" " onmouseout="volta_cor(this) " onmouseover="muda_cor(this)" onclick=location.href="index.php?rota=info_aluno&id=<?php echo $pedido->getAluno()->getId();?>"><?php echo $pedido->getAluno()->getNome(); ?></td>
                        <td class=" " onmouseout="volta_cor(this) " onmouseover="muda_cor(this)" onclick=location.href="index.php?rota=info_livro&id=<?php echo $pedido->getLivro()->getId();?>"><?php echo $pedido->getLivro()->getTitulo(); ?></td>
                        <td><?php echo $pedido->getCodigoLivro(); ?></td>
                        <td><?php echo $prazo; ?></td>
                         <td><a href="index.php?rota=remover_pedido&id=<?php echo $pedido->getId();?>">OK</a></td>
                    </tr>
                  <?php } ?>
<?php endforeach;  ?>




                </tbody>

          </table>
        </div>
        <div class="espaco-cima">
          <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
              <li class="page-item">
                <a class="page-link" href="index.php?rota=lista_pedidos&pagina=<?php echo 1; ?>" aria-label="Previous">
                  <<
                </a>
              </li>
             <?php for($i=0;$i<$num_paginas;$i++): ?>
               <?php $estilo= "";?>
               <?php if($pagina == $i+1){
                     $estilo ="active";
               }
               ?>
              <li class="page-item <?php echo $estilo;?>" ><a class="page-link" href="index.php?rota=lista_pedidos&pagina=<?php echo $i+1; ?>"><?php echo $i+1;?></a></li>

            <?php endfor; ?>
              <li class="page-item">
                <a class="page-link" href="index.php?rota=lista_pedidos&pagina=<?php echo $num_paginas; ?>" aria-label="Next">
                  >>
                </a>
              </li>
            </ul>
        </nav>

      </div>
      </div>
      <div class="col-md-6">
          <table class="table table-striped">
            <thead class="bg-danger text-white">
             <tr>
              <th>Turma</th>
              <th>Aluno</th>
              <th>Titulo</th>
              <th>Codigo do Livro</th>
              <th>Atrazo</th>
              <th>Ação</th>
             </tr>
            </thead>
           <tbody>
             <?php foreach ($pedidos_a as $pedido_a):?>
               <?php

               $data2 = new DateTime($pedido_a->getDataEntrega());

               $data_atual = new DateTime("now");

               $prazo = $data_atual->diff($data2);


               if($data2 < $data_atual){
                 $prazo ="-$prazo->d";


               }
               else{
                $prazo = $prazo->d;
              }
                ?>

             <?php if($prazo < 0){
             ?>
             <tr>
                  <td ><?php echo $pedido_a->getAluno()->getTurma(); ?> </td>
                  <td class=" " onmouseout="volta_cor(this) " onmouseover="muda_cor(this)" onclick=location.href="index.php?rota=info_aluno&id=<?php echo $pedido_a->getAluno()->getId();?>"><?php echo $pedido_a->getAluno()->getNome(); ?></td>
                  <td class=" " onmouseout="volta_cor(this) " onmouseover="muda_cor(this)" onclick=location.href="index.php?rota=info_livro&id=<?php echo $pedido_a->getLivro()->getId();?>"><?php echo $pedido_a->getLivro()->getTitulo(); ?></td>
                  <td><?php echo $pedido_a->getCodigoLivro(); ?></td>
                  <td><?php echo -$prazo; ?></td>
                   <td><a href="index.php?rota=remover_pedido&id=<?php echo $pedido_a->getId();?>">OK</a></td>
              </tr>
                <?php } ?>
              <?php endforeach; ?>
                </tbody>
            </table>


        </div>
      </div>
    </div>

    <!-- Tabela_Cadrastrados Fim -->
<script>
  function muda_cor(x){
   x.className="verde";

  }
  function volta_cor(x){
  x.className= " ";
  }


</script>
</body>
</html>
