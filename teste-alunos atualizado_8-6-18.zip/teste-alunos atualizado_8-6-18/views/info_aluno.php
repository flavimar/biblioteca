<!doctype html>
<html>
  <head>
    <title>Biblioteca||InfoAlunos</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>



    </style>
  </head>
  <body class="fundo-info">
   <div class="container cartao-info">
        <div class="row">
          <div class="col-md-4"></div>
          <div class="col-md-4"><h1>Dados do Aluno</h1></div>
        </div>
        <hr>
        <div class="row">
          <div class="col-md-6">
             <h4>Nome:</h4>
            <span> <?php echo $aluno->getNome() ?></span>
          </div>
          <div class="col-md-2 borda">
             <h4>Turma:</h4>
            <span> <?php echo $aluno->getTurma() ?></span>
          </div>
          <div class="col-md-4">
          </div>
          <hr>
        </div>
        <hr>
        <div class="row">

          <div class="col-md-4">
             <h4>Cidade:</h4>
             <span><?php echo $aluno->getCidade() ?></span>
          </div>
          <div class="col-md-4 borda">
             <h4>Bairro:</h4>
            <span>  <?php echo $aluno->getBairro()?></span>
          </div>

       </div>
       <hr>
       <div class="row">
         <div class="col-md-4">
            <h4>Rua:</h4>
            <span><?php echo $aluno->getRua() ?></span>
         </div>
         <div class="col-md-4 borda">
            <h4>N° Casa:</h4>
            <span><?php echo $aluno->getNumeroCasa() ?></span>
         </div>
          <div class="col-md-4 borda">
            <h4>Telefone:</h4>
            <span><?php echo $aluno->getTelefone() ?></span>
         </div>
       </div>
       <hr>
       <div class="row">
         <div class="col-md-12">
           <h4>Complementos:</h4>
           <span><?php echo $aluno->getComplementos() ?></span>
         </div>
       </div>
       <div class="row">
         <div class="col-md-12 espaco-cima">
            <button class="btn btn-block verde" onclick=location.href="index.php?rota=lista_pedidos">Voltar</button>
         </div>
       </div>

</div>





  </body>
<html>
