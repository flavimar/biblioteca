<?php
	class RepositorioPedidos{
		private $conexao;
		private $repositorio_alunos;

		public function __construct($conexao , $repositorio_alunos , $repositorio_livros){
			$this->conexao = $conexao;
			$this->repositorio_alunos = $repositorio_alunos;
      $this->repositorio_livros = $repositorio_livros;
		}

		public function adiciona_pedido($pedido){
			$sql = "INSERT INTO pedidos (codigo_aluno,codigo_livro,data_entrega,data_retirada) VALUES (:codigo_aluno,:codigo_livro,:data_entrega,NOW())";

			$query = $this->conexao->prepare($sql);
			//executa o SQL
			$query->execute(['codigo_aluno'=>$pedido->getCodigoAluno(),'codigo_livro'=>$pedido->getCodigoLivro(),'data_entrega'=>$pedido->getDataEntrega()]);


		}
		public function adiciona_pedidos_atrazados($pedido_a){
			$sql = "INSERT INTO pedidos_a (codigo_aluno,codigo_livro,data_entrega) VALUES (:codigo_aluno,:codigo_livro,:data_entrega)";

			$query = $this->conexao->prepare($sql);
			//executa o SQL
			$query->execute(['codigo_aluno'=>$pedido_a->getCodigoAluno(),'codigo_livro'=>$pedido_a->getCodigoLivro(),'data_entrega'=>$pedido_a->getDataEntrega()]);


		}

		//pega os alunos do Repositorio dos alunos e os pedidos da função busca_pedidos_por_id_aluno e junta eles
		/* public function busca_pedidos(){

            $pedidos = [];

            $alunos = $this->repositorio_alunos->busca_alunos();
            $livros = $this->repositorio_livros->busca_livros();



							foreach ($alunos as $aluno) {
                   foreach ($livros as $livro) {




								 $pedidos_de_aluno = RepositorioPedidos::busca_pedidos_por_id_aluno($aluno->getId(),$livro->getCodigo());

								 foreach ($pedidos_de_aluno as $pedido) {
                    $pedido->setAluno($aluno);
										$pedido->setLivro($livro);


								 }

								 foreach ($pedidos_de_aluno as $pedido) {
								 		$pedidos[]= $pedido;

								 }



}
						}

         return $pedidos;
		} */

		public function muda_pedidos_para_atrazados(){
     $sql = "SELECT * FROM pedidos WHERE data_entrega < NOW()";
			$resultado = $this->conexao->query($sql, PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 'Pedido');
			 $pedidos_a = [];

			 foreach ($resultado as $pedido_a){
					$pedidos_a[] = $pedido_a;
					$id = $pedido_a->getId();
					$sql_r = "DELETE FROM pedidos WHERE id = $id";

				 $query = $this->conexao->prepare($sql_r);

				 $query->execute(['id'=>$id]);

	 return	$pedido_a;
		}
		}
		public function busca_pedidos($pagina){
			$pedidos_por_pagina = 4;
			$pagina =($pagina-1)*$pedidos_por_pagina;

			 $sql = "SELECT * FROM pedidos LIMIT $pedidos_por_pagina OFFSET $pagina";
       $resultado = $this->conexao->query($sql, PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 'Pedido');
            $pedidos = [];


						foreach ($resultado as $pedido) {




								 $aluno = $this->repositorio_alunos->busca_aluno_por_pedido($pedido->getCodigoAluno());
								 $livro = $this->repositorio_livros->busca_livro_por_pedido($pedido->getCodigoLivro());


                    $pedido->setAluno($aluno);
										$pedido->setLivro($livro);






								 		$pedidos[]= $pedido;


							 }





         return $pedidos;
		}
		public function busca_pedidos_atrazados(){
			//$pedidos_por_pagina = 4;
			///$pagina =($pagina-1)*$pedidos_por_pagina;

			 $sql = "SELECT * FROM pedidos_a";
       $resultado = $this->conexao->query($sql, PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 'Pedido');
            $pedidos_a = [];


						foreach ($resultado as $pedido_a) {




								 $aluno = $this->repositorio_alunos->busca_aluno_por_pedido($pedido_a->getCodigoAluno());
								 $livro = $this->repositorio_livros->busca_livro_por_pedido($pedido_a->getCodigoLivro());


                    $pedido_a->setAluno($aluno);
										$pedido_a->setLivro($livro);






								 		$pedidos_a[]= $pedido_a;


							 }





         return $pedidos_a;
		}


		//busca todos os pedidos
		public function busca_pedidos_por_id_aluno($codigo_aluno,$codigo_livro){
	     $sql = "SELECT * FROM pedidos WHERE codigo_aluno = :codigo_aluno AND codigo_livro = :codigo_livro";
			 $query = $this->conexao->prepare($sql);
        $query->execute(['codigo_aluno'=>$codigo_aluno,'codigo_livro'=>$codigo_livro]);
				$query->setFetchMode(PDO::FETCH_CLASS|PDO::FETCH_PROPS_LATE, 'Pedido');
            $pedidos = [];

            while($pedido = $query->fetch()){
                $pedidos[] = $pedido;


            }
   			return $pedidos;
		}
		public function total_paginas(){
			$pedidos_por_pagina = 4;
     $sql="SELECT * FROM pedidos";
     $resultado = $this->conexao->query($sql, PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 'Pedido');
     $total_pedidos = [];
		 foreach ($resultado as $pedido) {
		 	$total_pedidos[]=$pedido;
		 }
		 $total_pedidos= (int)count($total_pedidos);
		 $num_paginas = ceil($total_pedidos/$pedidos_por_pagina);
		 return $num_paginas;
		}



		public function busca_aluno($id){
			$sql = "SELECT * FROM aluno WHERE id=:id";

			$query = $this->conexao->prepare($sql);

			$query->execute(['id'=>$id]);


       $query->setFetchMode(PDO::FETCH_CLASS|PDO::FETCH_PROPS_LATE, 'Aluno');
       $aluno = $query->fetch();
			return $aluno;
		}
		//atualiza os dados de um aluno
		public function atualiza($aluno){
			$sql = "UPDATE aluno SET nome=:nome,turma=:turma,telefone=:telefone,cidade=:cidade,bairro=:bairro,rua=:rua,numero_casa=:numero_casa,complementos=:complementos WHERE id=:id";

			$query = $this->conexao->prepare($sql);

			$query->execute(['nome'=>$aluno->getNome(),'turma'=>$aluno->getTurma(),'telefone'=>$aluno->getTelefone(), 'cidade'=>$aluno->getCidade(), 'bairro'=>$aluno->getBairro(), 'rua'=>$aluno->getRua(), 'numero_casa'=>$aluno->getNumeroCasa(), 'complementos'=>$aluno->getComplementos(), 'id'=>$aluno->getId()]);

		}



		//remove um aluno pelo id
		public function remove_pedido($id){
			$sql = "DELETE FROM pedidos WHERE id = :id";

			$query = $this->conexao->prepare($sql);

			$query->execute(['id'=>$id]);
		}
	}
?>
